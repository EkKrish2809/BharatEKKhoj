#version 460 core

/** Shader entry point. */
void main()
{
    
}
